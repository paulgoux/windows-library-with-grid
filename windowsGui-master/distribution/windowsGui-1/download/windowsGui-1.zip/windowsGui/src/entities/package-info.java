/**
 * 
 */
/**
 * @author paul goux
 *
 */
package entities;