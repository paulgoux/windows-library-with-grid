package windowsGui;

class rSpecies{
	float x,y,vx,vy;
	int type;
	public boolean toggle;
	public float intelligence;
	float skill;
	
	rSpecies(float X, float Y){
	  x = X;
	  y = Y;
	  vx = 2;
	  vy = 2;
	};
	
	rSpecies(){
	
	};
	
};