package windowsGui;

class Particle{
	float x,y,vx,vy;
	int type;
	public boolean toggle;
	public float intelligence;
	float skill;
	
	Particle(float X, float Y){
	  x = X;
	  y = Y;
	  vx = 2;
	  vy = 2;
	};
	
	Particle(){
	
	};
	
};
