package windowsGui;

class Species{
	float x,y,vx,vy;
	int id;
	public boolean toggle;
	public float intelligence;
	float skill;
	
	Species(float X, float Y){
	  x = X;
	  y = Y;
	  vx = 2;
	  vy = 2;
	};
	
	Species(){
	
	};
	
};
