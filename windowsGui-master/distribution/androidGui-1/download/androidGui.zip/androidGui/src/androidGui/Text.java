package androidGui;

import processing.core.PApplet;

public class Text{
	  PApplet applet;
	  public float x,y,textsize;
	  
	  public boolean visible;
	  public int col,col1,col2,col3,col4;
	  public String text = "";
	  public Text(float X,float y,String s){
	    x = X;
	    this.y = y;
	    
	    text = s;
	  };
	  
	  void draw(){
	      if(visible){
	        applet.fill(col);
	        applet.text(text,x,y);
	    }
	  };

	};
